# CarePulse — Patient MVP

Native Android patient application written in Kotlin and Jetpack Compose, with Google authentication and a Firebase Firestore repository. The project also includes a separate, interactive browser demo for reviewing the patient experience without an emulator.

## Implemented

- Google sign-in and sign-out; existing provider accounts are rejected without changing their role.
- Separate sample-patient mode that does not write demo records to Firebase.
- Today dashboard with date-aware medication progress and the next upcoming visit.
- Add daily medications, mark a dose taken, undo the mark, and remove an entry after confirmation.
- Record existing appointments, inspect details, and mark visits completed.
- Edit patient name, insurance provider, allergies, and emergency contact while preserving other profile fields.
- Firestore listeners, loading states, retry on record-loading failures, save-in-progress controls, and save/error feedback.
- Input validation for required values, field lengths, medication time, and calendar-valid appointment dates.
- Gradle wrapper launchers and wrapper JAR restored; local debug builds use Android's default debug signing when the AI Studio debug keystore is absent.

## Run Android

1. Open this directory in Android Studio with a compatible JDK and install the SDK requested by `app/build.gradle.kts` (compile SDK 36.1).
2. Set `sdk.dir` in local.properties if Android Studio does not configure it automatically.
3. Sync Gradle. Network access is required for the pinned Gradle 9.3.1 distribution and Maven dependencies.
4. Use the supplied Firebase project configuration only if you have access to that project. Otherwise replace `app/google-services.json` and the Firestore database/App Check resources with your own project settings.
5. For live sign-in, enable Google authentication and register the signing certificate fingerprints in Firebase. Register the development App Check debug token for debug builds; configure the existing release App Check integration before release testing.
6. Run `./gradlew :app:testDebugUnitTest :app:assembleDebug`, then install the generated `app/build/outputs/apk/debug/app-debug.apk` on a device or emulator.

The patient UI does not need a Gemini API key. The inherited AI service remains unconnected to these screens.

Release signing uses the existing KEYSTORE_PATH, STORE_PASSWORD, and KEY_PASSWORD environment configuration. No signing keys are included. Existing Firestore rules are supplied but were not deployed by this implementation work.

## Browser companion

Open `preview/index.html` in a browser. It supports navigation, add/remove daily medication entries, dose tracking and undo, appointment creation/completion, and profile edits. Everything is fictional, kept in memory, and reset on reload. It does not authenticate or connect to Firestore; the Android app owns that implementation.

Run browser logic checks with `node scripts/preview-checks.cjs` (Node 22 or another working recent Node installation).

## Verification on this machine

- Passed: standalone Kotlin checks for daily rollover, dose status, required fields, length limits, 24-hour time, leap years, and strict date parsing.
- Passed: Kotlin syntax parsing for all 19 Kotlin source files. This is not Android compilation/type checking.
- Passed: browser logic checks for progress, undo, record creation/removal, validation, visit completion, profile escaping, navigation, and modal rendering.
- Passed: shell syntax validation of the Gradle launcher.
- Blocked: full Android build and Android/JUnit execution. The wrapper attempt failed downloading Gradle with UnknownHostException for services.gradle.org; no Android SDK is installed here.
- Not verified: live Firebase sign-in, App Check, Firestore integration, emulator/device UI, or visual browser rendering. Existing Firestore emulator tests were not executed.

## Release limits

This is a patient MVP source handoff, not a verified production release or signed APK. Before distribution, build and run on a device; test Firebase authorization, two-account isolation, offline/reconnect behavior, midnight rollover, form rotation, and large-font layouts.

Medication tracking supports one daily dose per entry. It is not a full dose history, reminder scheduler, or prescription-management system. Demo state lasts for the ViewModel lifetime on Android and until reload in the browser. Live records persist through the existing Firestore repository; synchronization requires a correctly configured backend. If a save times out, check records before retrying because Firestore may still synchronize a pending write.

Appointments are personal records: adding or completing one does not book or cancel a visit, notify a provider, or send messages. Provider/insurer workflows, AI recommendations, insurance verification, calendar/email syncing, and notifications are not exposed in this MVP.

The older repository helpers and AI/coordination service remain in the source for future development. They have not been production-validated as part of this handoff.
